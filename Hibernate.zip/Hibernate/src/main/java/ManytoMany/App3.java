// Hiberante Many to Many 
package ManytoMany;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App3 {
public static void main(String[] args) {
	Configuration config = new Configuration();
	config.configure("hibernate3.cfg.xml");
	SessionFactory Factory= config.buildSessionFactory();
	Session session = Factory.openSession();
	Transaction tns = session.beginTransaction();

	Question q1= new Question();
	q1.setQname("What is Java?");
	
	Answer a1 = new Answer();
	a1.setAnswername("Java is Platform Independant");
	a1.setPostedby("Harini");
	
	Answer a2 = new Answer();
	a2.setAnswername("Object oriented programing language");
	a2.setPostedby("Prahanth");
	
	ArrayList<Answer> list1 = new ArrayList<Answer>();
	list1.add(a1);
	list1.add(a2);
	q1.setAnswer(list1);
	
	Question q2= new Question();
	q2.setQname("What is Exception?");
	
	Answer a3 = new Answer();
	a3.setAnswername("It interputs the flow of execution");
	a3.setPostedby("Alsara");
	
	Answer a4 = new Answer();
	a4.setAnswername("Types: Run-time and Compile-time");
	a4.setPostedby("Viha");
	
	ArrayList<Answer> list2 = new ArrayList<Answer>();
	list2.add(a3);
	list2.add(a4);
	q2.setAnswer(list2);
	
	session.persist(q1);
	session.persist(q2);
	
	tns.commit();
	session.close();
	Factory.close();
}
}
