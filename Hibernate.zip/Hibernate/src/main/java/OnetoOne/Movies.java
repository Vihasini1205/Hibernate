// Hibernate : One to One Method
package OnetoOne;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "movies")
public class Movies {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int movieId;
	    private String movieName;
	    private String actorName;
	    private String actressName;
	    
		public int getMovieId() {
			return movieId;
		}

		public String getMovieName() {
			return movieName;
		}

		public void setMovieName(String movieName) {
			this.movieName = movieName;
		}

		public String getActorName() {
			return actorName;
		}

		public void setActorName(String actorName) {
			this.actorName = actorName;
		}

		public String getActressName() {
			return actressName;
		}

		public void setActressName(String actressName) {
			this.actressName = actressName;
		}
}
