// Hibernate : One to One Method
package OnetoOne;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App {
public static void main(String[] args) {
	Configuration config = new Configuration();
	config.configure("hibernate.cfg.xml");
	SessionFactory sessionFactory= config.buildSessionFactory();
	
	Session session = sessionFactory.openSession();
	Transaction Trans = session.beginTransaction();
	
	Movies mov1 = new Movies();
	Songs son1= new Songs();
	
	mov1.setMovieName("Kushi");
	mov1.setActorName("Vijay");
	mov1.setActressName("Jothika");
	
	son1.setSongName("Oru Ponnu Onu");
	son1.setSinger("Deva,Anuradha");
	son1.setMusicDirector("Deva");
	
	son1.setMovies(mov1);
	session.persist(mov1);
	session.persist(son1);
	
	Trans.commit();
	session.close();
	sessionFactory.close();
	
	

}
}
