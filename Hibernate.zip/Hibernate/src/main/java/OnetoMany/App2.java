// Hibernate: One to Many 
package OnetoMany;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App2 {
public static void main(String[] args) {
	Configuration config = new Configuration();
	config.configure("hibernate2.cfg.xml");
	SessionFactory Factory= config.buildSessionFactory();
	Session session = Factory.openSession();
	Transaction tns = session.beginTransaction();
	
	Actors ats1 = new Actors();
	ats1.setActorname("Vijay");
	ats1.setAge("50");
	ats1.setSalary("60 cores");
	
	Actors ats2 = new Actors();
	ats2.setActorname("Vijay Sethupathi");
	ats2.setAge("47");
	ats2.setSalary("50 cores");
	
	Actors ats3 = new Actors();
	ats3.setActorname("Aishwarya Rai");
	ats3.setAge("51");
	ats3.setSalary("40 cores");
	
	 Actors ats4 = new Actors();
	 ats4.setActorname("Aishu");
	 ats4.setAge("33");
	 ats4.setSalary("40 cores");
	 
	 ArrayList<Actors> list1 = new ArrayList<Actors>();
	 list1.add(ats1);
	 list1.add(ats2);
	 
	 ArrayList<Actors> list2 = new ArrayList<Actors>();
	 list2.add(ats3);
	 list2.add(ats4);
	 
	 Movies2 m1 = new Movies2();
	 m1.setName("Master");
	 m1.setActors(list1);
	 
	 Movies2 m2 = new Movies2();
	 m2.setName("Ponniyin Selvan");
	 m2.setActors(list2);
	 
	 session.persist(m1);
	 session.persist(m2);
	 
	 tns.commit();
	 session.close();
	 Factory.close();
	 
}
}
