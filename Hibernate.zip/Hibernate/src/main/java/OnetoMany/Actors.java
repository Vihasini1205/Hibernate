// Hibernate: One to Many 
package OnetoMany;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Actors")
public class Actors {
	 @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	 
	 @Column(name="ActorName")
	 private String Actorname;
	 
	 @Column(name="Salary")
	 private String salary;
	 
	 @Column(name="Age")
	 private String age;
	 
	 public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getActorname() {
		return Actorname;
	}

	public void setActorname(String actorname) {
		Actorname = actorname;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}
}
