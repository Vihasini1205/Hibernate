//Hibernate: Many to One Method
package ManytoOne;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App4 {
	public static void main(String[] args) {
		Configuration config = new Configuration();
		config.configure("hibernate4.cfg.xml");
		SessionFactory sessionFactory = config.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		        
		        Employee e1=new Employee();
		        e1.setEmpname("Viha");
		        e1.setEmail("viha@gamil.com");
		       
		        Employee e2=new Employee();
		        e2.setEmpname("Sachin");
		        e2.setEmail("Sachin@gamil.com");
		       
		       
		        Address add1=new Address();
		        add1.setCity("T.nagar");
		        add1.setState("Chennai");
		        add1.setCountry("India");
		        add1.setPincode("625 001");
		       
		        e1.setAddress(add1);
		        e2.setAddress(add1);
		       
		       
		        Employee e3=new Employee();
		        e3.setEmpname("Suveetha");
		        e3.setEmail("suvee@gamil.com");
		       
		        Employee e4=new Employee();
		        e4.setEmpname("Alsara");
		        e4.setEmail("alsara@gamil.com");
		       
		       
		        Address add2=new Address();
		        add2.setCity("East Cross Street");
		        add2.setState("Madurai");
		        add2.setCountry("Tamil Nadu");
		        add2.setPincode("600 310");
		       
		        e3.setAddress(add2);
		        e4.setAddress(add2);
		       
		        session.persist(e1);
		        session.persist(e2);
		        session.persist(e3);
		        session.persist(e4);
		       
		        
		        tx.commit();
		        session.close();
		        sessionFactory.close();



		        System.out.println("Data inserted successfully!");	       
		}
	}

